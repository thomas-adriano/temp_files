./Squeak-5.0-All-in-One.app/Contents/LinuxAndWindows/squeak.sh
